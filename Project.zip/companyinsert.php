<?php
$name=$_POST['name_of_Company'];
$est=$_POST['Establishment_Date'];
$city=$_POST['City'];
$email=$_POST['email'];
$pass=$_POST['psw'];
$passr=$_POST['pswrep'];
if($pass!=$passr)
{
	echo "Passwords don't match";
	echo "<button type='button' onclick='<?php echo 'cosu.html'; ?>'>";
}
else
{
	$user="root";
	$pass="";
	$db='csr';
	$conn=mysqli_connect('localhost', $user, $pass, $db);
	if(!$conn)
	{
		die("Connection not successful".mysqli_connect_error());
	}
	else
	{
		$name=$_POST['name_of_Company'];

		$pass=$_POST['psw'];

	        $email=$_POST['email'];

	        $check = "SELECT * from ngotable where name='$_POST[name_of_Company]'";
	
        $lala = mysqli_query($conn, $check);

	        $data = mysqli_fetch_array($lala, MYSQLI_NUM);
		if(empty($name)||empty($email)||empty($pass))
    
		{

       
        		$errorMessage = "Oops! can't leave any field blank";

		        header("Location: cosu.html?login=error&message=".$errorMessage);
	
		}
		else if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email))

		{
		 
       $errorMessage = "Invalid email";
		
        header("Location: cosu.html?login=error&message=".$errorMessage);
		}

		else if($data[0] > 0)

		{

        
         	$errorMessage = "ALREADY REGISTERED";

		        header("Location: cosu.html?login=error&message=".$errorMessage);

		}

		else
		{
			$sql="insert into companytable values ('$name','$est','$city','$email','$pass')";

			if(mysqli_query($conn,$sql))
			{
				header("Location: login.html");
			}
			else
			{
				header("Location: cosu.html?login=error&message=".mysqli_error($conn));
			}
		}

	}
}
?>