<?php
$user="root";
$pass="";
$db='csr';
$conn=mysqli_connect('localhost', $user, $pass, $db);
if(!$conn)
{
	die("Connection not successful".mysqli_connect_error());
}
else
{
	echo "Successfully connected.<br>";
}
$sql="CREATE TABLE companytable(
		name VARCHAR(20),
		est DATE,
		city VARCHAR(20),
		email VARCHAR(30),
		password VARCHAR(10)
		);";
if(mysqli_query($conn,$sql))
{
	echo "Table created successfully";
}
else
{
	echo "Error created the table.".mysqli_error($conn);
}
?>
