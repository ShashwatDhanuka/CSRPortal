<?php
$i=$_POST['n'];
echo "<body style='background:url(s.jpg)'>";
echo "<body style='background-repeat:no-repeat'>";
echo "<h1 style='color:white;'>"."the CSR you got to pay is "."</h1>";
if( $i<10000000)
{
	$csr=2*$i/100;
echo "<h1 style='color:white;'>".$csr."</h1>";
}
else if ($i>10000000 && $i<30000000)
{
	$csr=2*10000;
	$csr=2*10000;
	$csr=$csr+($i-10000000)*2.2/100;
	echo $csr;
}
else
{
	
	$csr=2*10000;
	$csr=$csr+2.2*10000;
	$csr=$csr+($i-30000000)*2.5/100;
	echo "THE CSR YOU GOT TO PAY IS";
	ECHO "<br>";
	echo $csr;
}
?>