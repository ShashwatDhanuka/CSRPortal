<?php
$name=$_POST['name_of_NGO'];
$city=$_POST['City'];
$email=$_POST['email'];
$type=$_POST['Type_of_Ngo'];
$pass=$_POST['psw'];
$passr=$_POST['pswrep'];
if($pass!=$passr)
{
        $errorMessage = "Oops! Passwords don't match";
        header("Location: NGOSignUp.html?login=error&message=".$errorMessage);
    
}
else
{
	$user="root";
	$pass="";
	$db='csr';
	$conn=mysqli_connect('localhost', $user, $pass, $db);
	if(!$conn)
	{
		die("Connection not successful".mysqli_connect_error());
	}
	else
	{
		$name=$_POST['name_of_NGO'];

		$pass=$_POST['psw'];

	        $email=$_POST['email'];

	        $check = "SELECT * from ngotable where name='$_POST[name_of_NGO]'";
	
        $lala = mysqli_query($conn, $check);

	        $data = mysqli_fetch_array($lala, MYSQLI_NUM);
		if(empty($name)||empty($email)||empty($pass))
    
		{

       
        		$errorMessage = "Oops! can't leave any field blank";

		        header("Location: NGOSignUp.html?login=error&message=".$errorMessage);
	
		}
		else if(!preg_match("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^",$email))

		{
		 
       $errorMessage = "Invalid email";
		
        header("Location: NGOSignUp.html?login=error&message=".$errorMessage);
		}

		else if($data[0] > 0)

		{

        
         	$errorMessage = "ALREADY REGISTERED";

		        header("Location: NGOSignUp.html?login=error&message=".$errorMessage);

		}

		else
		{
			$sql="insert into ngotable values ('$name','$city','$email','$type','$pass')";

			if(mysqli_query($conn,$sql))
			{
				header("Location: login.html");
			}
			else
			{
				header("Location: NGOSignUp.html?login=error&message=".mysqli_error($conn));
			}
		}

	}


}
?>