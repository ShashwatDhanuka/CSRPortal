<?php
include_once 'database.php';
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$city_name = $_POST['city_name'];
$email = $_POST['email'];

/* sql query for inserting data into database */

mysqli_query($conn,"insert into mail (first_name,last_name,city_name,email) values ('$first_name','$last_name','$city_name','$email')") or die(mysqli_error($conn));
use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\Exception;

require 'E:\wamp64\bin\php\php7.2.14\PHPMailer\src\Exception.php';

/* The main PHPMailer class. */

require 'E:\wamp64\bin\php\php7.2.14\PHPMailer\src\PHPMailer.php';

/* SMTP class, needed if you want to use SMTP. */

require 'E:\wamp64\bin\php\php7.2.14\PHPMailer\src\SMTP.php';
/* creates object */
$mail = new PHPMailer(true);
$mailid = $email;
$subject = "Feedback Recieved";
$text_message = "Hello";
$message = "Dear User,<br><br> We are oblidged on recieving your valuable feedback.We will try and act upon it soon.<br><br>With Regards,<br><br>CSRPORTAL<br><br><br>For any queries,contact us on :-<br><br>Email:(csrportalbyshashwatandakanksha@gmail.com)<br><br>Phone:+919830167170";

try
{
$mail->IsSMTP();
$mail->isHTML(true);
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = "ssl";
$mail->Host = "smtp.gmail.com";
$mail->Port = '465';
$mail->AddAddress($mailid);
$mail->Username ="csrportalbyshashwatandakanksha@gmail.com";
$mail->Password ="123456789a@";
$mail->SetFrom('csrportalbyshashwatandakanksha@gmail.com','Shashwat & Aakankshas CSR Portal');
$mail->AddReplyTo("csrportalbyshashwatandakanksha@gmail.com","Shashwat & Aakankshas CSR Portal");
$mail->Subject = $subject;
$mail->Body = $message;
$mail->AltBody = $message;
if($mail->Send())
{
echo "Thank you for your valuable feedback.";
}
}
catch(phpmailerException $ex)
{
$msg = "
".$ex->errorMessage()."
";
}
?>