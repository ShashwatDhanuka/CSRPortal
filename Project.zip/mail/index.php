<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<head>
<style>
body  {
  background-image: url("feedbackbackg.jpg");
  background-color: #cccccc;
  
}
input[type=text] {
  
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid grey;
  border-radius: 4px;
}
input[type=email] {
  
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid grey;
  border-radius: 4px;
}
input[type=textbox] {
  
  padding: 42px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid grey;
  border-radius: 8px;
}
input[type=submit] {
  
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 2px solid grey;
  border-radius: 8px;
}
</style>
</head>
<body ><div class="w3-container w3-center w3-animate-top">
  <h1 style="font-size:50px;">FEEDBACK</h1>
  

<form method="post" action="mail-process.php">
First name:<br>
<input type="text" name="first_name"> 
<br>
Last name:<br>
<input type="text" name="last_name">
<br>
Feedback:<br>
<input type="textbox" name="city_name">
<br>
Email Id:<br>
<input type="email" name="email">
<br><br>
<input type="submit" name="save" value="Submit">
</form>

<button onclick="goBack()">Go Back</button>
</div>


<script>
function goBack() {
  window.history.back();
}
</script>

</body>
</html>