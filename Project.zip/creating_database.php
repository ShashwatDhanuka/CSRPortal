<?php
$user="root";
$pass="";
$conn=mysqli_connect('localhost', $user, $pass);
if(!$conn)
{
	die("Connection not successful".mysqli_connect_error());
}
else
{
	echo "Successfully connected.<br>";
}
$sql="CREATE DATABASE csr;";
if(mysqli_query($conn,$sql))
{
	echo "Database is created successfully";
}
else
{
	echo "Error created the database.".mysqli_error($conn);
}
?>
